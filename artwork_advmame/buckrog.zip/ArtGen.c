#include <stdio.h>

int main(int argc, char* argv[])
{
	FILE* fp = fopen("buckrog.art", "wt");

	if (fp != NULL)
	{
		int i, j;
		int n;

		fprintf(fp,
			"Panel:\n"
			"\tfile     = panel.png\n"
			"\tlayer    = panel\n"
			"\tposition = -59, 0, 0, 224\n"
			"\tpriority = -1\n"
			"\tvisible  = 1\n"
			"\n");

		for (i = 0; i < 5; i++)
		{
			for (j = 0; j <= 10; j++)
			{
				char c = (j == 10) ? 'X' : '0' + j;

				fprintf(fp,
					"LED%02d-%c:\n"
					"\tfile     = digit%c.png\n"
					"\tlayer    = panel\n"
					"\tposition = %d, %d, %d, %d\n"
					"\tvisible  = 0\n"
					"\n",
					i, c, c,
					-8 - i * 9 - 7, 18,
					-8 - i * 9 - 0, 31);
			}
		}

		for (n = 0; n < 5; n++)
		{
			int y1 = 50 + 15 * n;
			int y2 = 60 + 15 * n;

			for (i = 0; i < 5; i++)
			{
				for (j = 0; j <= 10; j++)
				{
					char c = (j == 10) ? 'X' : '0' + j;

					fprintf(fp,
						"LED%02d-%c:\n"
						"\tfile     = digit%c.png\n"
						"\tlayer    = panel\n"
						"\tposition = %d, %d, %d, %d\n"
						"\tvisible  = 0\n"
						"\n",
						5 * (n + 1) + i, c, c,
						-15 - i * 6 - 5, y1,
						-15 - i * 6 - 0, y2);
				}
			}
		}

		fclose(fp);
	}

	return 0;
}
