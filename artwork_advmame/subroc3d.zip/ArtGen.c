#include <stdio.h>

int main(int argc, char* argv[])
{
	FILE* fp = fopen("subroc3d.art", "wt");

	if (fp != NULL)
	{
		int i, j;
		int n;

		fprintf(fp,
			"Panel:\n"
			"\tfile     = panel.png\n"
			"\tlayer    = panel\n"
			"\tposition = 0, -47, 240, 0\n"
			"\tpriority = -1\n"
			"\tvisible  = 1\n"
			"\n");

		for (i = 0; i < 6; i++)
		{
			for (j = 0; j <= 10; j++)
			{
				char c = (j == 10) ? 'X' : '0' + j;

				fprintf(fp,
					"LED%02d-%c:\n"
					"\tfile     = digit%c.png\n"
					"\tlayer    = panel\n"
					"\tposition = %d, %d, %d, %d\n"
					"\tvisible  = 0\n"
					"\n",
					i ^ 1, c, c,
					167 + i * 11 + 0, -22,
					167 + i * 11 + 8, -10);
			}
		}

		for (n = 0; n < 3; n++)
		{
			for (i = 0; i < 6; i++)
			{
				for (j = 0; j <= 10; j++)
				{
					char c = (j == 10) ? 'X' : '0' + j;

					fprintf(fp,
						"LED%02d-%c:\n"
						"\tfile     = digit%c.png\n"
						"\tlayer    = panel\n"
						"\tposition = %d, %d, %d, %d\n"
						"\tvisible  = 0\n"
						"\n",
						6 * (n + 1) + (i ^ 1), c, c,
						116 - 53 * n + i * 6 + 0, -20,
						116 - 53 * n + i * 6 + 5, -10);
				}
			}
		}

		fclose(fp);
	}

	return 0;
}
